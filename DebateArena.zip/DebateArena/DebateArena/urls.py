"""
URL configuration for DebateArena project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.urls import include
from django.shortcuts import render
from django.views.generic import TemplateView
from auth_system.views import *
from DebateArena import settings
from django.conf import settings
from django.conf.urls.static import static


def home(request):
    return render(request, "home.html")

urlpatterns = [
    path('', home, name='home'),
    path('admin/', admin.site.urls),
    path('auth_system/', include('auth_system.urls')),
    path('comment_system/', include('comment_system.urls')),
    path('profile_system/', include('profile_system.urls')),
    path('debate_system/', include('debate_system.urls')),
    path('', TemplateView.as_view(template_name='home.html'), name='home'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)