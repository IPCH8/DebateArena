from django.db import models
from django.contrib.auth.models import User
from django import forms
from profile_system.models import UserProfile
# Create your models here
class UserSettings(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    email_notifications = models.BooleanField(default=True)
    dark_mode = models.BooleanField(default=False)
    show_online_status = models.BooleanField(default=True)
    preferred_theme = models.CharField(max_length=100, default='light')
    items_per_page = models.IntegerField(default=10)
    template = models.CharField(max_length=100, default='user_settings_page.html')

    def __str__(self):
        return f"Settings for {self.user.username}"

class SuperUserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True)
    website = models.URLField(blank=True)
    location = models.CharField(max_length=100, blank=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True)
    is_superuser_profile = models.BooleanField(default=True)
    template = models.CharField(max_length=100, default='superuser_profile_page.html')
    def __str__(self):
        return f"SuperUser Profile for {self.user.username}"
    

