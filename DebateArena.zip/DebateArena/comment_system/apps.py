from django.apps import AppConfig


class CommentSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'comment_system'
