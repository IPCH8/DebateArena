from django import forms
from comment_system.models import Comment

from django import forms
from comment_system.models import Comment

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'rows': 4, 'cols': 40, 'placeholder': 'Введіть ваш коментар...'}),
        }
        labels = {
            'text': 'Коментар',
        }


class ReplyForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'rows': 3, 'cols': 40, 'placeholder': 'Enter your reply here...'}),
        }
        labels = {
            'text': 'Reply',
        }

class EditCommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'rows': 4, 'cols': 40}),
        }
        labels = {
            'text': 'Edit Comment',
        }

class DeleteCommentForm(forms.Form):
    confirm = forms.BooleanField(label="Confirm deletion of this comment")

class ComplainCommentForm(forms.Form):
    reason = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 4, 'cols': 40, 'placeholder': 'Enter the reason for your complaint...'}),
        label='Reason for Complaint'
    )
        
