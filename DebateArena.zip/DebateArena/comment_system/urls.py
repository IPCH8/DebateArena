from django.urls import path
from .views import (
    CommentView,
    ReplyView,
    EditCommentView,
    DeleteCommentView,
    ComplainCommentView,
)

app_name = 'comment_system'

urlpatterns = [
    path('comment/<int:debate_id>/', CommentView.as_view(), name='comment_post'),
    path('reply/<int:comment_id>/', ReplyView.as_view(), name='comment_reply'),
    path('edit/<int:comment_id>/', EditCommentView.as_view(), name='comment_edit'),
    path('delete/<int:comment_id>/', DeleteCommentView.as_view(), name='comment_delete'),
    path('complain/<int:comment_id>/', ComplainCommentView.as_view(), name='comment_complain'),
]
