from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.contrib.auth.mixins import LoginRequiredMixin

from debate_system.models import Debate
from .models import Comment
from .forms import (
    CommentForm,
    ReplyForm,
    EditCommentForm,
    DeleteCommentForm,
    ComplainCommentForm
)

class CommentView(LoginRequiredMixin, View):
    def post(self, request, debate_id):
        debate = get_object_or_404(Debate, id=debate_id)

        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.author = request.user
            comment.debates = debate
            comment.save()
        return redirect("debate_system:debate_detail", debate_id=debate.id)



class ReplyView(LoginRequiredMixin, View):
    def post(self, request, comment_id):
        parent_comment = get_object_or_404(Comment, id=comment_id)

        form = ReplyForm(request.POST)
        if form.is_valid():
            reply = form.save(commit=False)
            reply.author = request.user
            reply.parent = parent_comment
            reply.debate = parent_comment.debate
            reply.save()

        return redirect(
            "debate_system:debate_detail",
            debate_id=parent_comment.debate.id
        )

class EditCommentView(LoginRequiredMixin, View):
    def get(self, request, comment_id):
        comment = get_object_or_404(Comment, id=comment_id, author=request.user)
        form = EditCommentForm(instance=comment)
        return render(request, "comment_system/edit_comment.html", {"form": form})

    def post(self, request, comment_id):
        comment = get_object_or_404(Comment, id=comment_id, author=request.user)
        form = EditCommentForm(request.POST, instance=comment)
        if form.is_valid():
            form.save()

        return redirect(
            "debate_system:debate_detail",
            debate_id=comment.debate.id
        )

class DeleteCommentView(LoginRequiredMixin, View):
    def post(self, request, comment_id):
        comment = get_object_or_404(Comment, id=comment_id, author=request.user)
        debate_id = comment.debate.id
        comment.delete()

        return redirect(
            "debate_system:debate_detail",
            debate_id=debate_id
        )

class ComplainCommentView(LoginRequiredMixin, View):
    def get(self, request, comment_id):
        form = ComplainCommentForm()
        return render(
            request,
            "comment_system/complain_comment.html",
            {"form": form}
        )

    def post(self, request, comment_id):
        form = ComplainCommentForm(request.POST)
        if form.is_valid():
            # Complaint.objects.create()
            pass

        comment = get_object_or_404(Comment, id=comment_id)
        return redirect(
            "debate_system:debate_detail",
            debate_id=comment.debate.id
        )
