from django.apps import AppConfig


class DebateSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'debate_system'
