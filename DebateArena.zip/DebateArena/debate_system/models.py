from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Debate(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='debates', null=True)

    def __str__(self):
        return self.title
    
class Vote(models.Model):
    CHOICES = [
        ('pro', 'Pro'),
        ('con', 'Con')
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    debate = models.ForeignKey(Debate, on_delete=models.CASCADE, related_name='votes', null=True)
    choice = models.CharField(max_length=10, choices=CHOICES)
    voted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'debate')

    def __str__(self):
        return f"{self.user} - {self.choice}"