from django.urls import path
from .views import (
    DebateListView,
    DebateCreateView,
    DebateUpdateView,
    DebateDeleteView,
    DebateView
)

app_name = 'debate_system'

urlpatterns = [
    path('', DebateListView.as_view(), name='debate_list'),
    path('create/', DebateCreateView.as_view(), name='create_debate'),
    path('<int:debate_id>/', DebateView.as_view(), name='debate_detail'),
    path('<int:debate_id>/update/', DebateUpdateView.as_view(), name='update_debate'),
    path('<int:debate_id>/delete/', DebateDeleteView.as_view(), name='delete_debate'),
    path('<int:debate_id>/create/', DebateCreateView.as_view(), name='create_debate'),
]
