from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from .models import Debate, Vote
from .forms import DebateForm, DebateDeleteForm, VoteForm
from comment_system.models import Comment

class DebateView(View):
    def get(self, request, debate_id):
        debate = get_object_or_404(Debate, id=debate_id)
        comments = Comment.objects.filter(debates=debate, parent=None).order_by('-created_at')

        votes_pro = Vote.objects.filter(debate=debate, choice='pro').count()
        votes_con = Vote.objects.filter(debate=debate, choice='con').count()

        total_votes = votes_pro + votes_con
        if total_votes > 0:
            pro_percentage = (votes_pro / total_votes) * 100
            con_percentage = (votes_con / total_votes) * 100
        else:
            pro_percentage = con_percentage = 0

        user_vote = None
        if request.user.is_authenticated:
            try:
                user_vote = Vote.objects.get(debate=debate, user=request.user)
            except Vote.DoesNotExist:
                user_vote = None

        context = {
            "debate": debate,
            "comments": comments,
            "user_vote": user_vote,
            "votes_pro": votes_pro,
            "votes_con": votes_con,
            "pro_percentage": pro_percentage,
            "con_percentage": con_percentage,
        }
        return render(request, 'debate_detail.html', context)

    def post(self, request, debate_id):
        debate = get_object_or_404(Debate, id=debate_id)

        choice = request.POST.get('vote_choice')
        if choice in ['pro', 'con'] and request.user.is_authenticated:
            vote, created = Vote.objects.get_or_create(debate=debate, user=request.user)
            vote.choice = choice
            vote.save()

        text = request.POST.get('text')
        if text and request.user.is_authenticated and 'parent_id' not in request.POST \
                and 'delete_comment' not in request.POST and 'complain_comment_id' not in request.POST:
            Comment.objects.create(debates=debate, author=request.user, text=text)

        parent_id = request.POST.get('parent_id')
        reply_text = request.POST.get('reply_text')
        if parent_id and reply_text and request.user.is_authenticated:
            parent_comment = get_object_or_404(Comment, id=parent_id)
            Comment.objects.create(debates=debate, author=request.user, text=reply_text, parent=parent_comment)

        delete_comment_id = request.POST.get('delete_comment')
        if delete_comment_id and request.user.is_authenticated:
            comment = get_object_or_404(Comment, id=delete_comment_id, author=request.user)
            comment.delete()

        return redirect('debate_system:debate_detail', debate_id=debate.id)




class DebateListView(View):
    def get(self, request):
        debates = Debate.objects.all()
        return render(request, 'debate_list.html', {'debates': debates})

class DebateCreateView(View):
    def get(self, request):
        form = DebateForm()
        return render(request, 'debate_create.html', {'form': form})

    def post(self, request):
        form = DebateForm(request.POST)
        if form.is_valid():
            debate = form.save(commit=False)  
            debate.creator = request.user     
            debate.save()                     
            return redirect('debate_system:debate_detail', debate_id=debate.id)
        return render(request, 'debate_create.html', {'form': form})


class DebateUpdateView(View):
    def get(self, request, debate_id):
        debate = get_object_or_404(Debate, id=debate_id)
        form = DebateForm(instance=debate)
        return render(request, 'debate_update.html', {'form': form})

    def post(self, request, debate_id):
        debate = get_object_or_404(Debate, id=debate_id)
        form = DebateForm(request.POST, instance=debate)
        if form.is_valid():
            debate = form.save()
            return redirect('debate_system:debate_detail', debate_id=debate.id)
        return render(request, 'debate_update.html', {'form': form})

class DebateDeleteView(View):
    def get(self, request, debate_id):
        debate = get_object_or_404(Debate, id=debate_id)
        return render(request, 'debate_delete.html', {'debate': debate})

    def post(self, request, debate_id):
        debate = get_object_or_404(Debate, id=debate_id)
        Vote.objects.filter(debate=debate).delete()

        def delete_comments(comment):
            for reply in comment.replies.all():
                delete_comments(reply)
            comment.delete()

        for comment in Comment.objects.filter(debates=debate, parent=None):
            delete_comments(comment)
        debate.delete()
        return redirect('debate_system:debate_list')


