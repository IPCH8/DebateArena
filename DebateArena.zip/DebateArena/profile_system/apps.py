from django.apps import AppConfig

class ProfileSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'profile_system'

    def ready(self):
        import profile_system.signals


