from django import forms
from profile_system.models import UserProfile


class ProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['bio', 'avatar', 'preferred_language']
        widgets = {
            'bio': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Tell us about yourself...'}),
            'preferred_language': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Preferred Language'}),
        }   

class AvatarUploadForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['avatar']
        widgets = {
            'avatar': forms.ClearableFileInput(attrs={'class': 'form-control-file'}),
        }
class BioUpdateForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['bio']
        widgets = {
            'bio': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Оновити біографію'}),
        }
class LanguagePreferenceForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['preferred_language']
        widgets = {
            'preferred_language': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Бажана мова'}),
        }

class TemplateSelectionForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['template']
        widgets = {
            'template': forms.Select(attrs={'class': 'form-control'}),
        }

