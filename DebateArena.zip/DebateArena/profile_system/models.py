from django.db import models
from django.contrib.auth.models import User
from django import forms
# Create your models here.

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True)
    avatar = models.ImageField(upload_to='images/', blank=True, null=True, default='images/default_avatar.png')
    template = models.CharField(max_length=100, default='profile.html')
    preferred_language = models.CharField(max_length=50, default='ua')

    def __str__(self):
        return self.user.username
    
class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['bio', 'avatar', 'preferred_language']