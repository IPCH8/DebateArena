from django.urls import path
from .views import (
    UserProfileView,
    #PublicProfileView,
    EditProfileView,
    AvatarUploadView,
    UpdateBioView,
)

app_name = 'profile_system'

urlpatterns = [
    path('profile/', UserProfileView.as_view(), name='profile'),
    #path('profile/<str:username>/', PublicProfileView.as_view(), name='view_profile'),
    path('profile/edit_profile/', EditProfileView.as_view(), name='edit_profile'),
    path('profile/upload_avatar/', AvatarUploadView.as_view(), name='upload_avatar'),
    path('profile/update_bio/', UpdateBioView.as_view(), name='update_bio'),

]

