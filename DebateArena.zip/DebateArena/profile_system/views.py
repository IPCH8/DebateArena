from django.shortcuts import render
from .models import UserProfile
from profile_system.forms import ProfileForm, AvatarUploadForm, BioUpdateForm, LanguagePreferenceForm
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views import View
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from .forms import ProfileForm

# Create your views here.
class UserProfileView(LoginRequiredMixin, View):
    def get(self, request):
        profile = get_object_or_404(UserProfile, user=request.user)
        return render(request, 'profile/profile.html', {
            'profile': profile
        })

class PublicProfileView(View):
    def get(self, request, username):
        user = get_object_or_404(User, username=username)
        profile = get_object_or_404(UserProfile, user=user)
        return render(request, 'profile/profile.html', {
            'profile': profile
        })

class EditProfileView(LoginRequiredMixin, View):
    def get(self, request):
        profile = get_object_or_404(UserProfile, user=request.user)
        form = ProfileForm(instance=profile)
        return render(request, 'settings/edit_profile.html', {'form': form, 'profile': profile})

    def post(self, request):
        profile = get_object_or_404(UserProfile, user=request.user)
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('profile_system:profile')
        return render(request, 'settings/edit_profile.html', {'form': form, 'profile': profile})


class AvatarUploadView(LoginRequiredMixin, View):
    def get(self, request):
        form = AvatarUploadForm(instance=request.user.userprofile)
        return render(request, 'settings/upload_avatar.html', {'form': form})

    def post(self, request):
        profile = request.user.userprofile
        form = AvatarUploadForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('profile_system:profile')
        return render(request, 'settings/upload_avatar.html', {'form': form})

        
class UpdateBioView(LoginRequiredMixin, View):
    def update_bio(self, request):
        profile = get_object_or_404(UserProfile, user=request.user)
        if request.method == 'POST':
            form = BioUpdateForm(request.POST, instance=profile)
            if form.is_valid():
                form.save()
                return redirect('profile_system:profile')
        else:
            form = BioUpdateForm(instance=profile)
        return render(request, 'edit_profile.html', {'form': form})
    
class SetLanguagePreference(LoginRequiredMixin, View):
    def set_language(self, request):
        profile = get_object_or_404(UserProfile, user=request.user)
        if request.method == 'POST':
            form = LanguagePreferenceForm(request.POST, instance=profile)
            if form.is_valid():
                form.save()
                return redirect('profile_system:profile')
        else:
            form = LanguagePreferenceForm(instance=profile)
        return render(request, 'settings/set_language.html', {'form': form})

def home(request):
    user = request.user
    context = {
        'user': user,
        'debates_won_count': user.profile.debates_won.count(),
        'votes_cast_count': user.profile.votes_cast.count(),
        'votes_received_count': user.profile.votes_received.count(),
    }
    return redirect('profile_system:profile')

